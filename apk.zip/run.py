import requests
import argparse
from functools import partial
from multiprocessing import Pool
from bs4 import BeautifulSoup as bsoup
import time

GREEN, RED = '\033[1;32m', '\033[91m'

banner = ''' 
    Made By: Topeng Galau
'''

def get_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('-q', '--query', dest='query', help='Specify the Search Query within \'\' or a file path containing queries')
    parser.add_argument('-e', '--engine', dest='engine', help='Specify the Search Engine (Google/Bing)')
    parser.add_argument('-p', '--pages', dest='pages', type=int, default=1, help='Specify the Number of Pages')
    parser.add_argument('-P', '--processes', dest='processes', type=int, default=2, help='Specify the Number of Processes')
    parser.add_argument('-o', '--output', dest='output', default='output.txt', help='Specify the Output File')
    return parser.parse_args()

def google_search(query, page):
    base_url = 'https://www.google.com/search'
    headers = { 'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:71.0) Gecko/20100101 Firefox/71.0' }
    params = { 'q': query, 'start': page * 10 }
    try:
        resp = requests.get(base_url, params=params, headers=headers)
        resp.raise_for_status()
        soup = bsoup(resp.text, 'html.parser')
        links = soup.find_all("div", class_="yuRUbf")
        return [link.find('a').get('href') for link in links]
    except requests.RequestException as e:
        print(RED + f"Error fetching Google search results: {e}")
        return []

def bing_search(query, page):
    base_url = 'https://www.bing.com/search'
    headers = { 'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:71.0) Gecko/20100101 Firefox/71.0' }
    params = { 'q': query, 'first': page * 10 + 1 }
    try:
        resp = requests.get(base_url, params=params, headers=headers)
        resp.raise_for_status()
        soup = bsoup(resp.text, 'html.parser')
        links = soup.find_all('cite')
        return [link.text for link in links]
    except requests.RequestException as e:
        print(RED + f"Error fetching Bing search results: {e}")
        return []

def search_result(query, engine, pages, processes, result, file_name):
    print('-' * 70)
    print(f'Searching for: {query} in {pages} page(s) of {engine} with {processes} processes')
    print('-' * 70)
    print()
    
    try:
        with open(file_name, 'a') as file:
            for range_result in result:
                for r in range_result:
                    file.write(r + '\n')  # Removed '[+] ' and headers
                    print('[+] ' + r)
    except IOError as e:
        print(RED + f"Error writing to file: {e}")
    
    print()
    print('-' * 70)

def main():
    options = get_arguments()

    if options.query:
        if options.query.endswith('.txt'):
            try:
                with open(options.query, 'r') as file:
                    queries = [line.strip() for line in file if line.strip()]
            except FileNotFoundError:
                print(RED + f"File {options.query} not found.")
                return
        else:
            queries = [options.query]
    else:
        queries = [input('[?] Enter the Search Query: ')]

    engine = options.engine.lower() if options.engine else input('[?] Choose the Search Engine (Google/Bing): ').lower()

    if engine == 'google':
        search_function = google_search
    elif engine == 'bing':
        search_function = bing_search
    else:
        print('[-] Invalid Option Entered!...Exiting the Program....')
        return

    pages = options.pages
    processes = options.processes
    file_name = options.output

    try:
        with open(file_name, 'w') as file:
            file.write(f'Results for search engine: {engine}\n')  # Only initial header
            file.write('-' * 70 + '\n')
    except IOError as e:
        print(RED + f"Error initializing file: {e}")
        return

    for query in queries:
        with Pool(processes) as p:
            result = p.map(partial(search_function, query), range(pages))
        
        search_result(query, engine, pages, processes, result, file_name)
        time.sleep(1)  # Simple delay to avoid rate limiting

print(GREEN + banner)

try:
    main()
except KeyboardInterrupt:
    print('\nThanks For using!')
except TimeoutError:
    print(RED + '\n[-] Too many requests, please try again later....')
